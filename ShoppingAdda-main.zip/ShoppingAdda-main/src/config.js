const firebaseConfig = {
    apiKey: "AIzaSyDzx77dioJ3IWsb2CYFDNlAf2kPTPpoBRk",
    authDomain: "autht-8647f.firebaseapp.com",
    projectId: "autht-8647f",
    storageBucket: "autht-8647f.appspot.com",
    messagingSenderId: "244082703409",
    appId: "1:244082703409:web:31b709dc49599ac0c26910"
};

export default firebaseConfig;